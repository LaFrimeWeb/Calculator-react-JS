import React, { useState } from 'react';

const Calculator = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonClick = (value) => {
    if (value === '=') {
      try {
        setResult(eval(input)); // Note : l'utilisation de eval peut être dangereuse
      } catch (e) {
        setResult('Error');
      }
    } else if (value === 'C') {
      setInput('');
      setResult('');
    } else {
      setInput(input + value);
    }
  };

  return (
    <div className="calculator">
      <div className="display">
        <div className="history">{input}</div>
        <div className="output">{result}</div>
      </div>
      <div className="keyboard">
        {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '=', '+'].map((btn) => (
          <button
            key={btn}
            className="btn"
            onClick={() => handleButtonClick(btn)}
          >
            {btn}
          </button>
        ))}
        <button className="btn clear" onClick={() => handleButtonClick('C')}>
          C
        </button>
      </div>
    </div>
  );
};

export default Calculator;